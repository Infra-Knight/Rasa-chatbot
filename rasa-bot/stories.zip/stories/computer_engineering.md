## computer_engineering_overview
* computer_engineering_overview{"14_majors": "computer engineering"}
    - utter_computer_engineering_overview

## computer_engineering_summary
* computer_engineering_summary{"14_majors": "computer engineering"}
    - utter_computer_engineering_summary

## computer_engineering_tuition_fee
* computer_engineering_tuition_fee_and_scholarship{"14_majors": "computer engineering"}
    - utter_computer_engineering_tuition_fee_and_scholarship

## computer_engineering_admission
* computer_engineering_admission_period{"14_majors": "computer engineering"}
    - utter_computer_engineering_admission_period

## computer_engineering_career_opportunity
* computer_engineering_career_opportunity{"14_majors": "computer engineering"}
    - utter_computer_engineering_career_opportunity

## computer_engineering_curriculum_structure
* computer_engineering_curriculum_structure{"14_majors": "computer engineering"}
    - utter_computer_engineering_curriculum_structure

## computer_engineering_transfer_opportunity
* computer_engineering_transfer_opportunity{"14_majors": "computer engineering"}
    - utter_computer_engineering_transfer_opportunity

## computer_engineering_1
* more_transfer_opportunity
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_transfer_opportunity

## computer_engineering_2
* more_curriculum_structure
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_curriculum_structure

## computer_engineering_3
* more_overview
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_overview

## computer_engineering_4
* more_admission_period
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_admission_period

## computer_engineering_5
* more_summary
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_summary

## computer_engineering_6
* more_tuition_fee_and_scholarship
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_tuition_fee_and_scholarship

## computer_engineering_7
* more_career_opportunity
    - slot{"14_majors": "computer engineering"}
    - utter_computer_engineering_career_opportunity

## computer_engineering_more
* more
    - slot{"14_majors": "computer engineering"}
    - utter_more_computer_engineering
    
## computer_engineering_more_who
* more_who
    - slot{"14_majors": "computer engineering"}
    - utter_more_who_computer_engineering
    
## computer_engineering_more_what
* more_what
    - slot{"14_majors": "computer engineering"}
    - utter_more_what_computer_engineering

## computer_engineering_more_when
* more_when
    - slot{"14_majors": "computer engineering"}
    - utter_more_when_computer_engineering

## computer_engineering_more_where
* more_where
    - slot{"14_majors": "computer engineering"}
    - utter_more_where_computer_engineering

## computer_engineering_more_why
* more_why
    - slot{"14_majors": "computer engineering"}
    - utter_more_why_computer_engineering
    
## computer_engineering_more_how
* more_how
    - slot{"14_majors": "computer engineering"}
    - utter_more_how_computer_engineering

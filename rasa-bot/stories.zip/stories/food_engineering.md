## food_engineering_overview
* food_engineering_overview{"14_majors": "food engineering"}
    - utter_food_engineering_overview

## food_engineering_summary
* food_engineering_summary{"14_majors": "food engineering"}
    - utter_food_engineering_summary

## food_engineering_tuition_fee
* food_engineering_tuition_fee_and_scholarship{"14_majors": "food engineering"}
    - utter_food_engineering_tuition_fee_and_scholarship

## food_engineering_admission
* food_engineering_admission_period{"14_majors": "food engineering"}
    - utter_food_engineering_admission_period

## food_engineering_career_opportunity
* food_engineering_career_opportunity{"14_majors": "food engineering"}
    - utter_food_engineering_career_opportunity

## food_engineering_curriculum_structure
* food_engineering_curriculum_structure{"14_majors": "food engineering"}
    - utter_food_engineering_curriculum_structure

## food_engineering_transfer_opportunity
* food_engineering_transfer_opportunity{"14_majors": "food engineering"}
    - utter_food_engineering_transfer_opportunity

## food_engineering_1
* more_transfer_opportunity
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_transfer_opportunity

## food_engineering_2
* more_curriculum_structure
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_curriculum_structure

## food_engineering_3
* more_overview
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_overview

## food_engineering_4
* more_admission_period
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_admission_period

## food_engineering_5
* more_summary
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_summary

## food_engineering_6
* more_tuition_fee_and_scholarship
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_tuition_fee_and_scholarship

## food_engineering_7
* more_career_opportunity
    - slot{"14_majors": "food engineering"}
    - utter_food_engineering_career_opportunity

## food_engineering_more
* more
    - slot{"14_majors": "food engineering"}
    - utter_more_food_engineering
    
## food_engineering_more_who
* more_who
    - slot{"14_majors": "food engineering"}
    - utter_more_who_food_engineering
    
## food_engineering_more_what
* more_what
    - slot{"14_majors": "food engineering"}
    - utter_more_what_food_engineering

## food_engineering_more_when
* more_when
    - slot{"14_majors": "food engineering"}
    - utter_more_when_food_engineering

## food_engineering_more_where
* more_where
    - slot{"14_majors": "food engineering"}
    - utter_more_where_food_engineering

## food_engineering_more_why
* more_why
    - slot{"14_majors": "food engineering"}
    - utter_more_why_food_engineering

## food_engineering_more_how
* more_how
    - slot{"14_majors": "food engineering"}
    - utter_more_how_food_engineering

## computer_science_overview
* computer_science_overview{"14_majors": "computer science"}
    - utter_computer_science_overview

## computer_science_summary
* computer_science_summary{"14_majors": "computer science"}
    - utter_computer_science_summary

## computer_science_tuition_fee
* computer_science_tuition_fee_and_scholarship{"14_majors": "computer science"}
    - utter_computer_science_tuition_fee_and_scholarship

## computer_science_admission
* computer_science_admission_period{"14_majors": "computer science"}
    - utter_computer_science_admission_period

## computer_science_career_opportunity
* computer_science_career_opportunity{"14_majors": "computer science"}
    - utter_computer_science_career_opportunity

## computer_science_curriculum_structure
* computer_science_curriculum_structure{"14_majors": "computer science"}
    - utter_computer_science_curriculum_structure

## computer_science_transfer_opportunity
* computer_science_transfer_opportunity{"14_majors": "computer science"}
    - utter_computer_science_transfer_opportunity

## computer_science_1
* more_transfer_opportunity
    - slot{"14_majors": "computer science"}
    - utter_computer_science_transfer_opportunity

## computer_science_2
* more_curriculum_structure
    - slot{"14_majors": "computer science"}
    - utter_computer_science_curriculum_structure

## computer_science_3
* more_overview
    - slot{"14_majors": "computer science"}
    - utter_computer_science_overview

## computer_science_4
* more_admission_period
    - slot{"14_majors": "computer science"}
    - utter_computer_science_admission_period

## computer_science_5
* more_summary
    - slot{"14_majors": "computer science"}
    - utter_computer_science_summary

## computer_science_6
* more_tuition_fee_and_scholarship
    - slot{"14_majors": "computer science"}
    - utter_computer_science_tuition_fee_and_scholarship

## computer_science_7
* more_career_opportunity
    - slot{"14_majors": "computer science"}
    - utter_computer_science_career_opportunity

## computer_science_more
* more
    - slot{"14_majors": "computer science"}
    - utter_more_computer_science
    
## computer_science_more_who
* more_who
    - slot{"14_majors": "computer science"}
    - utter_more_who_computer_science
    
## computer_science_more_what
* more_what
    - slot{"14_majors": "computer science"}
    - utter_more_what_computer_science

## computer_science_more_when
* more_when
    - slot{"14_majors": "computer science"}
    - utter_more_when_computer_science

## computer_science_more_where
* more_where
    - slot{"14_majors": "computer science"}
    - utter_more_where_computer_science

## computer_science_more_why
* more_why
    - slot{"14_majors": "computer science"}
    - utter_more_why_computer_science

## computer_science_more_how
* more_how
    - slot{"14_majors": "computer science"}
    - utter_more_how_computer_science
